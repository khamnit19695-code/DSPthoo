package com.example.mixdigitaldsp

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var mpManager: MediaProjectionManager

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, AudioCaptureService::class.java).apply {
                putExtra("RESULT_CODE", result.resultCode)
                putExtra("DATA", result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            captureLauncher.launch(mpManager.createScreenCaptureIntent())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
        }

        // สร้างสะพานเชื่อม JavaScript ให้กดปุ่ม "รับเสียงจากแอปอื่น" ในเว็บได้
        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun requestSystemAudio() {
                runOnUiThread {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        captureLauncher.launch(mpManager.createScreenCaptureIntent())
                    } else {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            }

            @JavascriptInterface
            fun stopSystemAudio() {
                runOnUiThread {
                    stopService(Intent(this@MainActivity, AudioCaptureService::class.java))
                }
            }
        }, "AndroidDSP")

        // รับเสียง PCM สดๆ จาก Service โยนเข้า Web Audio API
        AudioCaptureService.onAudioDataCallback = { base64Pcm ->
            runOnUiThread {
                webView.evaluateJavascript("if(window.onAndroidAudioData) window.onAndroidAudioData('$base64Pcm');", null)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
        }

        // โหลดหน้าเว็บ HTML ของมึง
        webView.loadUrl("file:///android_asset/index.html")
    }
}
