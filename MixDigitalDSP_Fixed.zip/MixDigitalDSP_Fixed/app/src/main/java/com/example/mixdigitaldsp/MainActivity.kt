package com.example.mixdigitaldsp

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var projectionManager: MediaProjectionManager
    private var pageReady = false
    private var pendingPcm: String? = null
    private var systemEqualizer: Equalizer? = null

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, AudioCaptureService::class.java).apply {
                putExtra("RESULT_CODE", result.resultCode)
                putExtra("DATA", result.data)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    startForegroundService(serviceIntent)
                else startService(serviceIntent)
                Log.i("MixDigitalDSP", "Service start requested after consent")
            } catch (e: Exception) {
                Log.e("MixDigitalDSP", "Cannot start capture service", e)
            }
        } else Log.w("MixDigitalDSP", "User cancelled screen/audio capture consent")
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
        else Log.e("MixDigitalDSP", "RECORD_AUDIO permission denied")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false

        webView.addJavascriptInterface(object {
            @JavascriptInterface fun requestSystemAudio() {
                runOnUiThread {
                    if (ContextCompat.checkSelfPermission(this@MainActivity,
                            Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
                    } else audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
            @JavascriptInterface fun enableSystemEqualizer(): String {
                return runCatching {
                    runOnUiThread { stopService(Intent(this@MainActivity, AudioCaptureService::class.java)) }
                    val eq = systemEqualizer ?: Equalizer(0, 0).also { systemEqualizer = it }
                    eq.enabled = true
                    val bands = eq.numberOfBands.toInt()
                    val range = eq.bandLevelRange
                    "พร้อมใช้งาน EQ ระบบ: $bands แบนด์ (${range[0] / 100} ถึง ${range[1] / 100} dB)"
                }.getOrElse { "เปิด System EQ ไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
            }
            @JavascriptInterface fun setSystemEqBand(freqHz: Int, gainDb: Float): String {
                return runCatching {
                    val eq = systemEqualizer ?: Equalizer(0, 0).also { systemEqualizer = it; it.enabled = true }
                    val count = eq.numberOfBands.toInt()
                    if (count <= 0) throw IllegalStateException("อุปกรณ์ไม่รายงานแบนด์ EQ")
                    var nearest: Short = 0
                    var distance = Long.MAX_VALUE
                    for (i in 0 until count) {
                        val center = eq.getCenterFreq(i.toShort()).toLong() / 1000L
                        val d = kotlin.math.abs(center - freqHz.toLong())
                        if (d < distance) { distance = d; nearest = i.toShort() }
                    }
                    val range = eq.bandLevelRange
                    val level = (gainDb * 100f).toInt().coerceIn(range[0].toInt(), range[1].toInt()).toShort()
                    eq.setBandLevel(nearest, level)
                    "ตั้ง $freqHz Hz ไปยังแบนด์อุปกรณ์ ${eq.getCenterFreq(nearest) / 1000} Hz"
                }.getOrElse { "ตั้ง EQ ไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
            }
            @JavascriptInterface fun disableSystemEqualizer() {
                runOnUiThread { try { systemEqualizer?.enabled = false } catch (_: Exception) {} }
            }
            @JavascriptInterface fun stopSystemAudio() {
                runOnUiThread { stopService(Intent(this@MainActivity, AudioCaptureService::class.java)) }
            }
        }, "AndroidDSP")

        AudioCaptureService.onAudioDataCallback = { pcm ->
            runOnUiThread {
                if (!pageReady) {
                    pendingPcm = pcm // retain latest block until page is ready
                } else sendPcmToWeb(pcm)
            }
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                pendingPcm?.let { sendPcmToWeb(it); pendingPcm = null }
                Log.i("MixDigitalDSP", "index.html loaded")
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun sendPcmToWeb(pcm: String) {
        // Base64 alphabet has no quote/backslash; still use a JS string safely.
        webView.evaluateJavascript(
            "if(typeof window.onAndroidAudioData==='function') window.onAndroidAudioData('$pcm');",
            null
        )
    }

    override fun onDestroy() {
        AudioCaptureService.onAudioDataCallback = null
        try { systemEqualizer?.release() } catch (_: Exception) {}
        systemEqualizer = null
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }
}
