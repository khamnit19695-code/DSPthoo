package com.example.mixdigitaldsp

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var projectionManager: MediaProjectionManager
    private var pageReady = false
    private var pendingPcm: String? = null

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, AudioCaptureService::class.java).apply {
                putExtra("RESULT_CODE", result.resultCode)
                putExtra("DATA", result.data)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    startForegroundService(serviceIntent)
                else startService(serviceIntent)
                Log.i("MixDigitalDSP", "Service start requested after consent")
            } catch (e: Exception) {
                Log.e("MixDigitalDSP", "Cannot start capture service", e)
            }
        } else Log.w("MixDigitalDSP", "User cancelled screen/audio capture consent")
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
        else Log.e("MixDigitalDSP", "RECORD_AUDIO permission denied")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false

        webView.addJavascriptInterface(object {
            @JavascriptInterface fun requestSystemAudio() {
                runOnUiThread {
                    if (ContextCompat.checkSelfPermission(this@MainActivity,
                            Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
                    } else audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
            @JavascriptInterface fun stopSystemAudio() {
                runOnUiThread { stopService(Intent(this@MainActivity, AudioCaptureService::class.java)) }
            }
        }, "AndroidDSP")

        AudioCaptureService.onAudioDataCallback = { pcm ->
            runOnUiThread {
                if (!pageReady) {
                    pendingPcm = pcm // retain latest block until page is ready
                } else sendPcmToWeb(pcm)
            }
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                pendingPcm?.let { sendPcmToWeb(it); pendingPcm = null }
                Log.i("MixDigitalDSP", "index.html loaded")
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun sendPcmToWeb(pcm: String) {
        // Base64 alphabet has no quote/backslash; still use a JS string safely.
        webView.evaluateJavascript(
            "if(typeof window.onAndroidAudioData==='function') window.onAndroidAudioData('$pcm');",
            null
        )
    }

    override fun onDestroy() {
        AudioCaptureService.onAudioDataCallback = null
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }
}
