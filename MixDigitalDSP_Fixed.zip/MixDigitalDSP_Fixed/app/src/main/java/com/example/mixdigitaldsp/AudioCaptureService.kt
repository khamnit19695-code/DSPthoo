package com.example.mixdigitaldsp

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioPlaybackCaptureConfiguration
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Base64
import android.util.Log
import androidx.core.app.NotificationCompat

class AudioCaptureService : Service() {
    companion object {
        private const val TAG = "MixDigitalDSP"
        private const val NOTIFICATION_ID = 1
        const val CHANNEL_ID = "DSP_CAPTURE_CHANNEL"
        @Volatile var onAudioDataCallback: ((String) -> Unit)? = null
    }

    @Volatile private var running = false
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var captureThread: Thread? = null
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.w(TAG, "MediaProjection stopped by system/user")
            stopCapture()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            createNotificationChannel()
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Mix Digital DSP")
                .setContentText("กำลังรับเสียงจากแอปอื่น")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true).build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else startForeground(NOTIFICATION_ID, notification)
            Log.i(TAG, "Foreground started")
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            stopSelf(startId)
            return START_NOT_STICKY
        }

        if (running) {
            Log.w(TAG, "Capture already running; ignoring duplicate start")
            return START_NOT_STICKY
        }

        val code = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("DATA", Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra("DATA") as? Intent
        }

        if (code != Activity.RESULT_OK || data == null) {
            Log.e(TAG, "Projection consent missing/cancelled")
            stopCapture()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            projection?.registerCallback(projectionCallback, android.os.Handler(mainLooper))
            Log.i(TAG, "MediaProjection created")
            beginAudio()
        } catch (e: Exception) {
            Log.e(TAG, "Projection setup failed", e)
            stopCapture()
        }
        return START_NOT_STICKY
    }

    private fun beginAudio() {
        val mp = projection ?: run { Log.e(TAG, "Projection null"); stopCapture(); return }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            Log.e(TAG, "Playback capture requires Android 10+"); stopCapture(); return
        }
        try {
            val captureConfig = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build()

            val rate = 44100
            val channel = AudioFormat.CHANNEL_IN_MONO
            val encoding = AudioFormat.ENCODING_PCM_16BIT
            val format = AudioFormat.Builder().setSampleRate(rate)
                .setChannelMask(channel).setEncoding(encoding).build()
            val min = AudioRecord.getMinBufferSize(rate, channel, encoding)
            if (min <= 0) throw IllegalStateException("getMinBufferSize returned $min")
            val rec = AudioRecord.Builder().setAudioFormat(format)
                .setBufferSizeInBytes(maxOf(min * 4, 16384))
                .setAudioPlaybackCaptureConfig(captureConfig).build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                throw IllegalStateException("AudioRecord not initialized")
            }
            recorder = rec
            rec.startRecording()
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING)
                throw IllegalStateException("AudioRecord did not enter RECORDING state")

            running = true
            Log.i(TAG, "AudioRecord recording; minBuffer=$min")
            captureThread = Thread({ readLoop(rec) }, "DSP-AudioCapture").apply {
                start()
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Capture security/permission error", e); stopCapture()
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord setup error", e); stopCapture()
        }
    }

    private fun readLoop(rec: AudioRecord) {
        val buffer = ByteArray(8192)
        var blocks = 0
        Log.i(TAG, "PCM read loop started")
        while (running) {
            val count = try {
                rec.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
            } catch (e: Exception) {
                Log.e(TAG, "AudioRecord.read exception", e); break
            }
            if (count > 0) {
                val valid = count - count % 2
                if (valid > 0) {
                    try {
                        val encoded = Base64.encodeToString(buffer, 0, valid, Base64.NO_WRAP)
                        onAudioDataCallback?.invoke(encoded)
                        blocks++
                        if (blocks == 1) Log.i(TAG, "First PCM block delivered ($valid bytes)")
                        if (blocks % 100 == 0) Log.d(TAG, "PCM blocks=$blocks")
                    } catch (e: Exception) {
                        Log.e(TAG, "PCM callback failed", e)
                    }
                }
            } else if (count == 0) {
                Log.w(TAG, "AudioRecord.read returned 0")
            } else {
                Log.e(TAG, "AudioRecord.read error=$count")
                break
            }
        }
        Log.i(TAG, "PCM read loop ended")
    }

    private fun stopCapture() {
        running = false
        try { recorder?.stop() } catch (e: Exception) { Log.w(TAG, "recorder stop", e) }
        try { recorder?.release() } catch (e: Exception) { Log.w(TAG, "recorder release", e) }
        recorder = null
        try {
            projection?.unregisterCallback(projectionCallback)
            projection?.stop()
        } catch (e: Exception) { Log.w(TAG, "projection stop", e) }
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
        Log.i(TAG, "Service destroyed")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "DSP Audio Capture",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
