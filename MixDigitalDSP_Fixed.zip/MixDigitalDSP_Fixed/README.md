# Mix Digital DSP

Android project. GitHub Actions builds a debug APK on pushes to `main`/`master` and on manual workflow runs.

## Build
The workflow uses JDK 17 and Gradle 8.7, then runs `gradle assembleDebug` and uploads `app-debug.apk` as an Actions artifact.

Note: Android playback capture is subject to Android's MediaProjection consent and app audio-capture policy. Some apps may block capture; this project cannot guarantee capture from every app.
