# Mix Digital DSP

Android project. GitHub Actions builds a debug APK on pushes to `main`/`master` and on manual workflow runs.

## Build
The workflow uses JDK 17 and Gradle 8.7, then runs `gradle assembleDebug` and uploads `app-debug.apk` as an Actions artifact.

Note: Android playback capture is subject to Android's MediaProjection consent and app audio-capture policy. Some apps may block capture; this project cannot guarantee capture from every app.

## System EQ mode (anti-echo change)
The System/AUX button now uses Android's native `Equalizer` output-mix effect (audio session 0) rather than capturing PCM with MediaProjection and replaying it through WebView. This avoids the app's previous duplicate-monitor path, which caused the original source plus delayed processed audio to be heard together.

Important device limitation: Android documents global output-mix insert effects on session 0 as deprecated. Some OEM ROMs permit them, some may reject them or not apply them to all playback streams. The UI reports the effect status. The Android native Equalizer exposes the device's available bands (often fewer than the UI's 7); each UI frequency slider is routed to the nearest native band, so multiple UI sliders may affect the same hardware band. File/URL player EQ remains WebAudio-based.
